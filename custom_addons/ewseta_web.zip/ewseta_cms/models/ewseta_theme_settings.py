# -*- coding: utf-8 -*-

import json

from odoo import api, fields, models
from odoo.exceptions import ValidationError


class EwsetaThemeSettings(models.Model):
    _name = 'ewseta.theme.settings'
    _description = 'EWSETA Website Theme Settings'
    _inherit = ['mail.thread']

    name = fields.Char(default='Theme Settings', required=True)
    website_id = fields.Many2one(
        'website',
        ondelete='restrict',
        default=lambda self: self.env.ref('website.default_website', raise_if_not_found=False),
    )
    is_active = fields.Boolean(default=True)
    theme_toggle_enabled = fields.Boolean(
        string='Show Theme Toggle Button',
        default=True,
        help='Display the theme cycle button in the website header.',
    )
    remember_user_choice = fields.Boolean(
        string='Remember Visitor Choice',
        default=True,
        help='When enabled, the visitor\'s last selected theme is stored in the browser.',
    )
    default_theme = fields.Selection(
        selection=[
            ('light', 'White (Light)'),
            ('dark', 'Dark'),
            ('blue', 'Blue'),
            ('green', 'Green'),
            ('orange', 'Orange'),
        ],
        string='Default Theme',
        default='light',
        required=True,
    )
    enable_dark_theme = fields.Boolean(string='Enable Dark Theme', default=True)
    enable_blue_theme = fields.Boolean(string='Enable Blue Theme', default=True)
    enable_green_theme = fields.Boolean(string='Enable Green Theme', default=True)
    enable_orange_theme = fields.Boolean(string='Enable Orange Theme', default=True)

    _website_uniq = models.Constraint(
        'unique(website_id)',
        'Only one theme settings record is allowed per website.',
    )

    @api.model
    def get_for_website(self, website_id=None):
        domain = [('is_active', '=', True)]
        if website_id:
            domain.append(('website_id', '=', website_id))
        return self.sudo().search(domain, limit=1)

    def _available_themes(self):
        self.ensure_one()
        themes = ['light']
        if self.enable_dark_theme:
            themes.append('dark')
        if self.enable_blue_theme:
            themes.append('blue')
        if self.enable_green_theme:
            themes.append('green')
        if self.enable_orange_theme:
            themes.append('orange')
        return themes

    def get_frontend_config(self):
        self.ensure_one()
        themes = self._available_themes()
        default_theme = self.default_theme if self.default_theme in themes else 'light'
        toggle_enabled = self.theme_toggle_enabled and len(themes) > 1
        return {
            'toggleEnabled': toggle_enabled,
            'defaultTheme': default_theme,
            'rememberUserChoice': self.remember_user_choice,
            'themes': themes,
        }

    @api.model
    def _default_frontend_config(self):
        return {
            'toggleEnabled': True,
            'defaultTheme': 'light',
            'rememberUserChoice': True,
            'themes': ['light', 'dark', 'blue', 'green', 'orange'],
        }

    @api.model
    def get_frontend_config_json(self, website_id=None):
        settings = self.get_for_website(website_id)
        config = settings.get_frontend_config() if settings else self._default_frontend_config()
        return json.dumps(config)

    @api.model
    def is_toggle_enabled_for_website(self, website_id=None):
        settings = self.get_for_website(website_id)
        config = settings.get_frontend_config() if settings else self._default_frontend_config()
        return config['toggleEnabled']

    @api.constrains(
        'default_theme',
        'enable_dark_theme',
        'enable_blue_theme',
        'enable_green_theme',
        'enable_orange_theme',
    )
    def _check_default_theme(self):
        for record in self:
            if record.default_theme not in record._available_themes():
                raise ValidationError(
                    'The default theme must be one of the enabled themes.'
                )

    @api.model
    def seed_default_content(self):
        website = self.env.ref('website.default_website', raise_if_not_found=False)
        if not website:
            return
        if self.search_count([('website_id', '=', website.id)]):
            return
        self.create({
            'name': 'Theme Settings',
            'website_id': website.id,
        })
