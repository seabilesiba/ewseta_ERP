/** @odoo-module **/

import { Interaction } from "@web/public/interaction";
import { registry } from "@web/core/registry";

const STORAGE_KEY = "ewseta-theme";
const ALL_THEMES = ["light", "dark", "blue", "green", "orange"];

export function getEwsetaThemeConfig() {
    const config = window.ewsetaThemeConfig;
    if (config && Array.isArray(config.themes) && config.themes.length) {
        return config;
    }
    return {
        toggleEnabled: true,
        defaultTheme: "light",
        rememberUserChoice: true,
        themes: ALL_THEMES,
    };
}

export function getEwsetaThemes() {
    return getEwsetaThemeConfig().themes;
}

export function applyEwsetaTheme(theme) {
    const html = document.documentElement;
    const themes = getEwsetaThemes();
    const resolvedTheme = themes.includes(theme) ? theme : getEwsetaThemeConfig().defaultTheme || "light";

    html.classList.remove(
        "ewseta-dark-mode",
        "ewseta-blue-mode",
        "ewseta-green-mode",
        "ewseta-orange-mode",
    );
    if (resolvedTheme === "dark") {
        html.classList.add("ewseta-dark-mode");
    } else if (resolvedTheme === "blue") {
        html.classList.add("ewseta-blue-mode");
    } else if (resolvedTheme === "green") {
        html.classList.add("ewseta-green-mode");
    } else if (resolvedTheme === "orange") {
        html.classList.add("ewseta-orange-mode");
    }
    html.dataset.ewsetaTheme = resolvedTheme;
    return resolvedTheme;
}

export function getStoredEwsetaTheme() {
    try {
        return localStorage.getItem(STORAGE_KEY);
    } catch {
        return null;
    }
}

export function resolveEwsetaTheme() {
    const config = getEwsetaThemeConfig();
    const themes = config.themes;

    if (config.rememberUserChoice) {
        const stored = getStoredEwsetaTheme();
        if (stored && themes.includes(stored)) {
            return stored;
        }
    }

    if (themes.includes(config.defaultTheme)) {
        return config.defaultTheme;
    }
    return themes[0] || "light";
}

export class EwsetaDarkMode extends Interaction {
    static selector = ".ewseta-theme-toggle";

    dynamicContent = {
        _root: { "t-on-click": this.onToggle },
    };

    start() {
        applyEwsetaTheme(resolveEwsetaTheme());
        return super.start();
    }

    onToggle() {
        const themes = getEwsetaThemes();
        const current = document.documentElement.dataset.ewsetaTheme || resolveEwsetaTheme();
        const index = themes.indexOf(current);
        const nextIndex = index >= 0 ? (index + 1) % themes.length : 0;
        const nextTheme = applyEwsetaTheme(themes[nextIndex]);
        if (getEwsetaThemeConfig().rememberUserChoice) {
            try {
                localStorage.setItem(STORAGE_KEY, nextTheme);
            } catch {
                // Private browsing or blocked storage — theme still toggles for this page.
            }
        }
    }
}

registry.category("public.interactions").add("ewseta_web.dark_mode", EwsetaDarkMode);
